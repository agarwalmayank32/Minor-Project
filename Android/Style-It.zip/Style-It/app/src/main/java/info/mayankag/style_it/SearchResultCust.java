package info.mayankag.style_it;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import info.mayankag.style_it.Adapter.SearchResultAdapterCust;
import info.mayankag.style_it.Model.ShopDetailsForCustomerSearch;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SearchResultCust extends AppCompatActivity {

    TextView noQueryResultText;
    ListView searchResultList;

    ArrayList<ShopDetailsForCustomerSearch> queryResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result_cust);

        noQueryResultText = findViewById(R.id.noQueryResultText);
        searchResultList = findViewById(R.id.searchResultList);
        queryResult = new ArrayList<>();
        Bundle extra = getIntent().getExtras();
        if(extra!=null)
        {
            //noinspection unchecked
            new getSearchResultHandler().execute(extra.getString("query"));
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class getSearchResultHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/search_query";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(SearchResultCust.this);
            pDialog.setMessage("Fetching details....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            RequestBody formBody = new FormBody.Builder()
                    .add("search",params[0].toString())
                    .build();


            Request.Builder builder = new Request.Builder();
            builder.url(url).header("token" ,Util.getToken(SearchResultCust.this)).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            }
            else
            {
                try
                {
                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":

                            JSONArray detail = response.getJSONArray("data");

                            if(detail.length()>0)
                            {
                                queryResult.clear();

                                searchResultList.setVisibility(View.VISIBLE);
                                noQueryResultText.setVisibility(View.GONE);

                                for (int i = 0; i < detail.length(); i++) {
                                    JSONObject singleObject = detail.getJSONObject(i);

                                    int open = Integer.parseInt(singleObject.getString("opentime"));
                                    int close = Integer.parseInt(singleObject.getString("closetime"));
                                    String service = singleObject.getString("service");
                                    String opTime,clTime;

                                    if(open>12)
                                    {
                                        opTime = String.valueOf(open-12)+" PM";
                                    }
                                    else if(open == 12)
                                    {
                                        opTime = String.valueOf(open)+" PM";
                                    }
                                    else
                                    {
                                        opTime = String.valueOf(open)+" AM";
                                    }

                                    if(close>12)
                                    {
                                        clTime = String.valueOf(close-12)+" PM";
                                    }
                                    else if(close == 12)
                                    {
                                        clTime = String.valueOf(close)+" PM";
                                    }
                                    else
                                    {
                                        clTime = String.valueOf(close)+" AM";
                                    }

                                    queryResult.add(new ShopDetailsForCustomerSearch(
                                            singleObject.getString("sid"),singleObject.getString("shopname"),
                                            opTime,clTime,service));
                                }

                                SearchResultAdapterCust adapter = new SearchResultAdapterCust(SearchResultCust.this,queryResult);
                                searchResultList.setAdapter(adapter);
                            }
                            else
                            {
                                searchResultList.setVisibility(View.GONE);
                                noQueryResultText.setVisibility(View.VISIBLE);
                            }

                            break;
                        case "400":
                            break;
                        case "401":
                        case "422":
                            Toast.makeText(SearchResultCust.this,"error",Toast.LENGTH_SHORT).show();
                            break;
                        case "402":
                            Toast.makeText(SearchResultCust.this,"Invalid User",Toast.LENGTH_SHORT).show();
                            Util.logout(SearchResultCust.this);
                            break;
                        default:

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}