package info.mayankag.style_it.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import info.mayankag.style_it.Model.ShopDetailsForCustomerSearch;
import info.mayankag.style_it.R;
import info.mayankag.style_it.SelectTimeAndSlotCust;

public class SearchResultAdapterCust extends ArrayAdapter<ShopDetailsForCustomerSearch> {

    private Activity mContext;
    private ArrayList<ShopDetailsForCustomerSearch> shopDetailsForCustomerSearches;

    public SearchResultAdapterCust(Activity context, ArrayList<ShopDetailsForCustomerSearch> shopDetailsForCustomerSearches) {
        super(context, R.layout.searchresultadapter, shopDetailsForCustomerSearches);

        mContext = context;
        this.shopDetailsForCustomerSearches = shopDetailsForCustomerSearches;
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = mContext.getLayoutInflater();
        @SuppressLint("ViewHolder")
        final View rowView = inflater.inflate(R.layout.searchresultadapter, null, true);

        TextView name = rowView.findViewById(R.id.nameShopSearch);
        TextView opentime = rowView.findViewById(R.id.openTimeSearch);
        TextView closetime = rowView.findViewById(R.id.closeTimeSearch);
        Button bookSearch = rowView.findViewById(R.id.bookSearch);

        name.setText(shopDetailsForCustomerSearches.get(position).getShopName());
        opentime.setText(shopDetailsForCustomerSearches.get(position).getOpenTime());
        closetime.setText(shopDetailsForCustomerSearches.get(position).getCloseTime());

        bookSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.startActivity(new Intent(mContext, SelectTimeAndSlotCust.class)
                        .putExtra("sid",shopDetailsForCustomerSearches.get(position).getShopid())
                        .putExtra("service",shopDetailsForCustomerSearches.get(position).getService()));
                mContext.finish();
            }
        });

        return rowView;

    }
}