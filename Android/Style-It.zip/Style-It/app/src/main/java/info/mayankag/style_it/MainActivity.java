package info.mayankag.style_it;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences pref = getApplicationContext().getSharedPreferences("STYLEIT", MODE_PRIVATE);
        String type = pref.getString("userType",null);

        /*if(type != null)
        {
            if(type.equals("shopkeeper"))
            {
                startActivity(new Intent(this,LoginShop.class));
                finish();
            }
            else if(type.equals("customer"))
            {
                startActivity(new Intent(this,LoginCustomer.class));
                finish();
            }
        }*/
    }

    public void onShopkeeperSelect(View view)
    {
        SharedPreferences pref = getApplicationContext().getSharedPreferences("STYLEIT", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("userType", "shopkeeper");
        editor.apply();
        startActivity(new Intent(this,LoginShop.class));
        finish();
    }

    public void onCustomerSelect(View view)
    {
        SharedPreferences pref = getApplicationContext().getSharedPreferences("STYLEIT", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("userType", "customer");
        editor.apply();
        startActivity(new Intent(this,LoginCustomer.class));
        finish();
    }
}
