package info.mayankag.style_it.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import info.mayankag.style_it.Model.PastBookingDetailsShop;
import info.mayankag.style_it.R;

public class PastBookingDetailsAdapterShop extends ArrayAdapter<PastBookingDetailsShop> {

    private Activity mContext;
    private ArrayList<PastBookingDetailsShop> pastBookingDetailsShops;

    public PastBookingDetailsAdapterShop(Activity context, ArrayList<PastBookingDetailsShop> pastBookingDetailsShops) {
        super(context, R.layout.pastbookinghistoryadaptershop, pastBookingDetailsShops);

        mContext = context;
        this.pastBookingDetailsShops = pastBookingDetailsShops;
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = mContext.getLayoutInflater();
        @SuppressLint({"ViewHolder", "InflateParams"})
        final View rowView = inflater.inflate(R.layout.pastbookinghistoryadaptershop, null, true);

        TextView bookingCustName = rowView.findViewById(R.id.pastBookingCustname);
        TextView bookingDate = rowView.findViewById(R.id.pastBookingDateShop);
        TextView bookingTime = rowView.findViewById(R.id.pastBookingTimeShop);
        TextView bookingService = rowView.findViewById(R.id.pastBookingServiceShop);
        TextView bookingStatus = rowView.findViewById(R.id.pastBookingStatusShop);

        bookingCustName.setText(pastBookingDetailsShops.get(position).getBookingCustName());
        bookingDate.setText(pastBookingDetailsShops.get(position).getBookingDate());
        bookingTime.setText(pastBookingDetailsShops.get(position).getBookingTime());
        bookingService.setText(pastBookingDetailsShops.get(position).getBookingService());
        bookingStatus.setText(pastBookingDetailsShops.get(position).getBookingStatus());

        return rowView;

    }
}