package info.mayankag.style_it;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SignUpShop extends AppCompatActivity {

    EditText shopname,shopkeepername,email,phone,password;

    String open,close;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_shop);

        shopname = findViewById(R.id.enterNameShop);
        shopkeepername = findViewById(R.id.enterNameShopkeeper);
        email = findViewById(R.id.enterEmailShop);
        phone = findViewById(R.id.enterPhoneShop);
        password = findViewById(R.id.enterPasswordShop);
        Spinner openTime = findViewById(R.id.openTime);
        Spinner closeTime = findViewById(R.id.closeTime);

        final List<String> list = new ArrayList<>();
        list.add("Select Opening Time");
        list.add("09:00");
        list.add("10:00");
        list.add("11:00");
        ArrayAdapter<String> openTimeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, list);
        openTimeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        openTime.setAdapter(openTimeAdapter);

        final List<String> list1 = new ArrayList<>();
        list1.add("Select Closing Time");
        list1.add("21:00");
        list1.add("22:00");
        list1.add("23:00");
        ArrayAdapter<String> closeTimeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, list1);
        closeTimeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        closeTime.setAdapter(closeTimeAdapter);

        openTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                open = list.get(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        closeTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                close = list1.get(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void signupShop(View view)
    {
        if(Util.networkConnectionCheck(this))
        {
            Toast.makeText(SignUpShop.this,open,Toast.LENGTH_SHORT).show();
            Toast.makeText(SignUpShop.this,close,Toast.LENGTH_SHORT).show();
            //noinspection unchecked
            new SignUpHandler().execute(shopname.getText().toString(),shopkeepername.getText().toString(),email.getText().toString(),phone.getText().toString(), password.getText().toString(),open,close);
        }
        else
        {
            Util.networkToast(this);
        }
    }

    public void loginShopFromSignup(View view)
    {
        startActivity(new Intent(this,LoginShop.class));
        finish();
    }

    @SuppressLint("StaticFieldLeak")
    private class SignUpHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/signup_shop";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(SignUpShop.this);
            pDialog.setMessage("Logging In....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {
            RequestBody formBody = new FormBody.Builder()
                    .add("shopname", params[0].toString())
                    .add("name", params[1].toString())
                    .add("email", params[2].toString())
                    .add("phone", params[3].toString())
                    .add("password", params[4].toString())
                    .add("opentime", params[5].toString())
                    .add("closetime", params[6].toString())
                    .build();

            Request.Builder builder = new Request.Builder();
            builder.url(url).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            } else {
                try {

                    //Toast.makeText(Login.this, o.toString(),Toast.LENGTH_SHORT).show();

                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":
                            JSONObject res = new JSONObject(response.getString("data"));

                            SharedPreferences pref = getApplicationContext().getSharedPreferences("STYLEIT", MODE_PRIVATE);
                            SharedPreferences.Editor editor = pref.edit();

                            editor.putString("sid", res.getString("sid"));
                            editor.putString("token", res.getString("token"));

                            editor.apply();
                            editor.commit();
                            startActivity(new Intent(SignUpShop.this,MainActivityShop.class));
                            finish();

                            break;
                        case "400":
                            Toast.makeText(getApplicationContext(), response.getString("UsersMessage"), Toast.LENGTH_LONG).show();
                            break;
                        case "422":
                            if (response.getString("DeveloperMessage").contains("Phone Number field is required")) {
                                Toast.makeText(getApplicationContext(), "Phone Number field is required", Toast.LENGTH_LONG).show();
                            } else if (response.getString("DeveloperMessage").contains("Email address field is required")) {
                                Toast.makeText(getApplicationContext(), "Email address field is required", Toast.LENGTH_LONG).show();
                            } else if (response.getString("DeveloperMessage").contains("Name field is required")) {
                                Toast.makeText(getApplicationContext(), "Name field is required", Toast.LENGTH_LONG).show();
                            } else if (response.getString("DeveloperMessage").contains("Password field is required")) {
                                Toast.makeText(getApplicationContext(), "Password field is required", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                            }
                            break;
                        default:
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        Util.onBackPressed(SignUpShop.this);
    }
}
