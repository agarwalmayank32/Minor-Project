package info.mayankag.style_it;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import info.mayankag.style_it.Adapter.PastBookingDetailsAdapterShop;
import info.mayankag.style_it.Model.PastBookingDetailsShop;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class BookingHistoryShop extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    ArrayList<PastBookingDetailsShop> bookingDetails;

    ListView bookingHistory;
    TextView noBookingHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_history_shop);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        bookingDetails = new ArrayList<>();

        bookingHistory = findViewById(R.id.bookingHistoryShop);
        noBookingHistory = findViewById(R.id.noBookingHistoryShop);

        //noinspection unchecked
        new bookingHistoryHandler().execute();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_shop, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if(id == R.id.check_booking)
        {
            finish();
        }
        else if(id == R.id.past_booking)
        {
        }
        else if(id == R.id.my_services)
        {
            startActivity(new Intent(this,ServiceShop.class));
        }
        else if(id == R.id.logoutShop)
        {
            Util.logout(this);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @SuppressLint("StaticFieldLeak")
    private class bookingHistoryHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/booking_history_shop";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(BookingHistoryShop.this);
            pDialog.setMessage("Fetching Your Past Bookings....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            RequestBody formBody = new FormBody.Builder()
                    .add("sid",Util.getShopID(BookingHistoryShop.this))
                    .build();


            Request.Builder builder = new Request.Builder();
            builder.url(url).header("token" ,Util.getToken(BookingHistoryShop.this)).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            }
            else
            {
                try
                {
                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":

                            JSONArray detail = response.getJSONArray("data");

                            Toast.makeText(BookingHistoryShop.this,Util.getShopID(BookingHistoryShop.this),Toast.LENGTH_SHORT).show();

                            if(detail.length()>0)
                            {
                                bookingDetails.clear();

                                bookingHistory.setVisibility(View.VISIBLE);
                                noBookingHistory.setVisibility(View.GONE);

                                for (int i = 0; i < detail.length(); i++) {
                                    JSONObject singleObject = detail.getJSONObject(i);

                                    bookingDetails.add(new PastBookingDetailsShop(
                                            singleObject.getString("custname"),singleObject.getString("date"),
                                            singleObject.getString("time"),singleObject.getString("service"),
                                            singleObject.getString("status")));
                                }

                                PastBookingDetailsAdapterShop adapter = new PastBookingDetailsAdapterShop(BookingHistoryShop.this,bookingDetails);
                                bookingHistory.setAdapter(adapter);
                            }
                            else
                            {
                                bookingHistory.setVisibility(View.GONE);
                                noBookingHistory.setVisibility(View.VISIBLE);
                            }

                            break;
                        case "400":
                            bookingHistory.setVisibility(View.GONE);
                            noBookingHistory.setVisibility(View.VISIBLE);
                            break;
                        case "401":
                        case "422":
                            Toast.makeText(BookingHistoryShop.this,"error",Toast.LENGTH_SHORT).show();
                            break;
                        case "402":
                            Toast.makeText(BookingHistoryShop.this,"Invalid User",Toast.LENGTH_SHORT).show();
                            Util.logout(BookingHistoryShop.this);
                            break;
                        default:

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
