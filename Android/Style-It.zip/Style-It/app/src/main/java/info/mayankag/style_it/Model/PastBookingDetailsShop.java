package info.mayankag.style_it.Model;

public class PastBookingDetailsShop {

    private String bookingCustName;
    private String bookingDate;
    private String bookingTime;
    private String bookingService;
    private String bookingStatus;

    public PastBookingDetailsShop(String bookingCustName, String bookingDate, String bookingTime, String bookingService, String bookingStatus)
    {
        this.bookingCustName = bookingCustName;
        this.bookingDate = bookingDate;
        this.bookingTime = bookingTime;
        this.bookingService = bookingService;
        this.bookingStatus = bookingStatus;
    }

    public String getBookingCustName() {
        return bookingCustName;
    }

    public void setBookingCustName(String bookingCustName) {
        this.bookingCustName = bookingCustName;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(String bookingTime) {
        this.bookingTime = bookingTime;
    }

    public String getBookingService() {
        return bookingService;
    }

    public void setBookingService(String bookingService) {
        this.bookingService = bookingService;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

}
