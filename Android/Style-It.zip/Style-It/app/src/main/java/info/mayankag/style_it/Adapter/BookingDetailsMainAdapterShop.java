package info.mayankag.style_it.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import info.mayankag.style_it.MainActivityShop;
import info.mayankag.style_it.Model.BookingDetailsMainShop;
import info.mayankag.style_it.R;
import info.mayankag.style_it.Util;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class BookingDetailsMainAdapterShop extends ArrayAdapter<BookingDetailsMainShop> {

    private Activity mContext;
    private ArrayList<BookingDetailsMainShop> bookingDetailsMainShop;

    public BookingDetailsMainAdapterShop(Activity context, ArrayList<BookingDetailsMainShop> bookingDetailsMainShop) {
        super(context, R.layout.bookinghistoryadaptershop, bookingDetailsMainShop);

        mContext = context;
        this.bookingDetailsMainShop = bookingDetailsMainShop;
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = mContext.getLayoutInflater();
        @SuppressLint({"ViewHolder", "InflateParams"})
        final View rowView = inflater.inflate(R.layout.bookinghistoryadaptershop, null, true);

        TextView bookingCustName = rowView.findViewById(R.id.bookingCustname);
        TextView bookingDate = rowView.findViewById(R.id.bookingDateShop);
        TextView bookingTime = rowView.findViewById(R.id.bookingTimeShop);
        TextView bookingService = rowView.findViewById(R.id.bookingServiceShop);

        Button bookingAccept = rowView.findViewById(R.id.bookingAccept);
        Button bookingReject = rowView.findViewById(R.id.bookingReject);

        bookingAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //noinspection unchecked
                new BookingStatusHandler().execute(bookingDetailsMainShop.get(position).getBookingID(),"Accepted");
            }
        });

        bookingReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //noinspection unchecked
                new BookingStatusHandler().execute(bookingDetailsMainShop.get(position).getBookingID(),"Rejected");
            }
        });

        bookingCustName.setText(bookingDetailsMainShop.get(position).getBookingCustName());
        bookingDate.setText(bookingDetailsMainShop.get(position).getBookingDate());
        bookingTime.setText(bookingDetailsMainShop.get(position).getBookingTime());
        bookingService.setText(bookingDetailsMainShop.get(position).getBookingService());

        return rowView;
    }

    @SuppressLint("StaticFieldLeak")
    private class BookingStatusHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/accept_or_reject_booking";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(mContext);
            pDialog.setMessage("Confirming Status of Booking....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            RequestBody formBody = new FormBody.Builder()
                    .add("bid", params[0].toString())
                    .add("status", params[1].toString())
                    .build();


            Request.Builder builder = new Request.Builder();
            builder.url(url).header("token" ,Util.getToken(mContext)).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(mContext, "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            }
            else
            {
                try
                {
                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":

                            mContext.startActivity(new Intent(mContext,MainActivityShop.class));
                            mContext.finish();

                            break;
                        case "400":
                            break;
                        case "401":
                        case "422":
                            Toast.makeText(mContext,"Invalid User", Toast.LENGTH_SHORT).show();
                            Util.logout(mContext);
                            break;
                        default:

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}