package info.mayankag.style_it;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import static android.content.Context.MODE_PRIVATE;

public class Util {

    public static String getCustID(Context context)
    {
        SharedPreferences pref = context.getSharedPreferences("STYLEIT", MODE_PRIVATE);
        return pref.getString("custid", null);
    }

    public static String getShopID(Context context)
    {
        SharedPreferences pref = context.getSharedPreferences("STYLEIT", MODE_PRIVATE);
        return pref.getString("sid", null);
    }

    public static String getToken(Context context)
    {
        SharedPreferences pref = context.getSharedPreferences("STYLEIT", MODE_PRIVATE);
        return pref.getString("token", null);
    }

    static boolean networkConnectionCheck(Context context)
    {
        ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    static void networkToast(Context context)
    {
        Toast.makeText(context,"Internet not connected. Please connect to internet.",Toast.LENGTH_SHORT).show();
    }

    static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }

    public static void setupUI(View view, final Activity activity) {

        // Set up touch listener for non-text box views to hide keyboard.
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    hideSoftKeyboard(activity);
                    return false;
                }
            });
        }

        //If a layout container, iterate over children and seed recursion.
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupUI(innerView, activity);
            }
        }
    }

    public static void onBackPressed(final Activity activity) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(activity);

        builder.setTitle("Exit");
        builder.setMessage("Do you want to exit? ");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                activity.finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.show();
    }

    public static void logout(Activity context)
    {
        SharedPreferences pref = context.getSharedPreferences("STYLEIT", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("userType", null);
        editor.putString("sid", null);
        editor.putString("custid", null);
        editor.putString("token", null);
        editor.apply();
        editor.commit();
        context.startActivity(new Intent(context,MainActivity.class));
        context.finish();
    }
}
