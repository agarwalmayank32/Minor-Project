package info.mayankag.style_it;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginShop extends AppCompatActivity {

    EditText input, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_shop);

        SharedPreferences pref = getApplicationContext().getSharedPreferences("STYLEIT", MODE_PRIVATE);
        String sid = pref.getString("sid",null);

        if(sid != null)
        {
            startActivity(new Intent(this,MainActivityShop.class));
            finish();
        }

        input = findViewById(R.id.inputShop);
        password = findViewById(R.id.passwordShop);
    }

    public void loginShop(View view)
    {
        if(Util.networkConnectionCheck(this))
        {
            //noinspection unchecked
            new LoginHandler().execute(input.getText().toString(), password.getText().toString());
        }
        else
        {
            Util.networkToast(this);
        }
    }

    boolean isEmailValid(CharSequence email)
    {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public void signupshop(View view) {
        startActivity(new Intent(LoginShop.this,SignUpShop.class));
        finish();
    }

    @SuppressLint("StaticFieldLeak")
    private class LoginHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/login_shop";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        String type;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(LoginShop.this);
            pDialog.setMessage("Logging In....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            if (isEmailValid(params[0].toString())) {
                type = "email";
            } else {
                type = "phone";
            }

            RequestBody formBody = new FormBody.Builder()
                    .add("input", params[0].toString())
                    .add("password", params[1].toString())
                    .add("type", type)
                    .build();

            Request.Builder builder = new Request.Builder();
            builder.url(url).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            } else {
                try {

                    //Toast.makeText(Login.this, o.toString(),Toast.LENGTH_SHORT).show();

                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":
                            JSONObject res = new JSONObject(response.getString("data"));

                            SharedPreferences pref = getApplicationContext().getSharedPreferences("STYLEIT", MODE_PRIVATE);
                            SharedPreferences.Editor editor = pref.edit();

                            editor.putString("sid", res.getString("sid"));
                            editor.putString("token", res.getString("token"));

                            editor.apply();
                            editor.commit();
                            //startActivity(new Intent(LoginCustomer.this,.class));
                            finish();

                            break;
                        case "401":
                            Toast.makeText(getApplicationContext(), "Incorrect Credentials", Toast.LENGTH_LONG).show();
                            break;
                        case "422":
                            if (response.getString("DeveloperMessage").contains("Password field is required")) {
                                Toast.makeText(getApplicationContext(), "Password field is required", Toast.LENGTH_LONG).show();
                            } else if (response.getString("DeveloperMessage").contains("Email address field is required")) {
                                Toast.makeText(getApplicationContext(), "Email address field is required", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                            }
                            break;
                        default:
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        Util.onBackPressed(LoginShop.this);
    }
}
