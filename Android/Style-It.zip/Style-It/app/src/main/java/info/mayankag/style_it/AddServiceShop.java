package info.mayankag.style_it;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AddServiceShop extends AppCompatActivity {

    ArrayList<String> services;

    Spinner service;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_service_shop);

        service = findViewById(R.id.service);

        services = new ArrayList<>();
        fetchServices();

        service.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(position>0)
                {
                    //noinspection unchecked
                    new AddServiceHandler().execute(services.get(position));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }
    
    void fetchServices()
    {
        if(Util.networkConnectionCheck(this))
        {
            //noinspection unchecked
            new FetchServiceHandler().execute(Util.getToken(this));
        }
        else
        {
            Util.networkToast(this);
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class FetchServiceHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/get_all_services_shop";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(AddServiceShop.this);
            pDialog.setMessage("Fetching Services....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            RequestBody formBody = new FormBody.Builder()
                    .build();


            Request.Builder builder = new Request.Builder();
            builder.url(url).header("token" ,Util.getToken(AddServiceShop.this)).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            }
            else
            {
                try
                {
                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":

                            JSONArray detail = response.getJSONArray("data");

                            if(detail.length()>0)
                            {
                                services.clear();

                                services.add("Select Service");

                                for (int i = 0; i < detail.length(); i++) {
                                    JSONObject singleObject = detail.getJSONObject(i);
                                    services.add(singleObject.getString("servicename"));
                                }

                                ArrayAdapter<String> timeAdapter = new ArrayAdapter<>(AddServiceShop.this, android.R.layout.simple_spinner_item, services);
                                timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                service.setAdapter(timeAdapter);

                            }
                            break;
                        case "400":
                            break;
                        case "401":
                        case "422":
                            Toast.makeText(AddServiceShop.this,"Invalid User", Toast.LENGTH_SHORT).show();
                            Util.logout(AddServiceShop.this);
                            break;
                        default:

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class AddServiceHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/add_service_shop";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(AddServiceShop.this);
            pDialog.setMessage("Fetching Services....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            RequestBody formBody = new FormBody.Builder()
                    .add("sid",Util.getShopID(AddServiceShop.this))
                    .add("service",params[0].toString())
                    .build();


            Request.Builder builder = new Request.Builder();
            builder.url(url).header("token" ,Util.getToken(AddServiceShop.this)).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            }
            else
            {
                try
                {
                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":

                            Toast.makeText(AddServiceShop.this,"Service added Successfully",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(AddServiceShop.this,MainActivityShop.class));
                            break;
                        case "400":
                            break;
                        case "401":
                        case "422":
                            Toast.makeText(AddServiceShop.this,"Invalid User", Toast.LENGTH_SHORT).show();
                            Util.logout(AddServiceShop.this);
                            break;
                        default:

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
