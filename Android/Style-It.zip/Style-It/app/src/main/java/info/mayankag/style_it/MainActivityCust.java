package info.mayankag.style_it;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.mancj.materialsearchbar.MaterialSearchBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivityCust extends AppCompatActivity implements
        NavigationView.OnNavigationItemSelectedListener, MaterialSearchBar.OnSearchActionListener{

    ListView serviceListView;
    ArrayList<String> services;
    TextView noServiceFetchText;

    MaterialSearchBar searchBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_cust);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        services = new ArrayList<>();
        serviceListView = findViewById(R.id.selectService);
        noServiceFetchText = findViewById(R.id.noServiceFetchText);
        fetchServices();

        searchBar = findViewById(R.id.searchBar);

        searchBar.setHint("Search a particular Service");
        searchBar.setPlaceHolder("Search a particular Service");
        searchBar.setSpeechMode(true);
        searchBar.setRoundedSearchBarEnabled(true);
        searchBar.setOnSearchActionListener(this);

        serviceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                startActivity(new Intent(MainActivityCust.this,SearchResultCust.class).putExtra("query",services.get(position)));
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            Util.onBackPressed(MainActivityCust.this);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_cust, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.search_service) {

        } else if (id == R.id.booking_history) {
            startActivity(new Intent(this,BookingHistoryCust.class));
        } else  if (id == R.id.logoutCust) {
            Util.logout(MainActivityCust.this);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    void fetchServices()
    {
        if(Util.networkConnectionCheck(this))
        {
            //noinspection unchecked
            new FetchServiceHandler().execute();
        }
        else
        {
            Util.networkToast(this);
        }
    }

    @Override
    public void onSearchStateChanged(boolean enabled) {
        searchBar.setHint("Search a particular Service");
        searchBar.setPlaceHolder("Search a particular Service");
    }

    @Override
    public void onSearchConfirmed(CharSequence text) {
        startActivity(new Intent(MainActivityCust.this,SearchResultCust.class).putExtra("query",searchBar.getText()));
    }

    @Override
    public void onButtonClicked(int buttonCode) {
        switch (buttonCode) {
            case MaterialSearchBar.BUTTON_SPEECH:
                Toast.makeText(this, "This Feature is not available right now", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class FetchServiceHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/get_all_services_cust";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(MainActivityCust.this);
            pDialog.setMessage("Fetching Services....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            RequestBody formBody = new FormBody.Builder()
                    .build();


            Request.Builder builder = new Request.Builder();
            builder.url(url).header("token" ,Util.getToken(MainActivityCust.this)).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            }
            else
            {
                try
                {
                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":

                            JSONArray detail = response.getJSONArray("data");

                            if(detail.length()>0)
                            {
                                services.clear();

                                serviceListView.setVisibility(View.VISIBLE);
                                noServiceFetchText.setVisibility(View.GONE);

                                for (int i = 0; i < detail.length(); i++) {
                                    JSONObject singleObject = detail.getJSONObject(i);
                                    services.add(singleObject.getString("servicename"));
                                }

                                ArrayAdapter adapter = new ArrayAdapter<>(MainActivityCust.this,android.R.layout.simple_list_item_1,services);
                                serviceListView.setAdapter(adapter);
                            }
                            else
                            {
                                serviceListView.setVisibility(View.GONE);
                                noServiceFetchText.setVisibility(View.VISIBLE);
                            }

                            break;
                        case "400":
                            break;
                        case "401":
                        case "422":
                            Toast.makeText(MainActivityCust.this,"Invalid User", Toast.LENGTH_SHORT).show();
                            Util.logout(MainActivityCust.this);
                            break;
                        default:

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
