package info.mayankag.style_it;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SignUpCustomer extends AppCompatActivity {

    EditText name,email,phone,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_customer);

        name = findViewById(R.id.enterNameCust);
        email = findViewById(R.id.enterEmailCust);
        phone = findViewById(R.id.enterPhoneCust);
        password = findViewById(R.id.enterPasswordCust);
    }

    public void signupCust(View view)
    {
        if(Util.networkConnectionCheck(this))
        {
            //noinspection unchecked
            new SignUpHandler().execute(name.getText().toString(),email.getText().toString(),phone.getText().toString(), password.getText().toString());
        }
        else
        {
            Util.networkToast(this);
        }
    }

    public void loginCustomerFromSignup(View view)
    {
        startActivity(new Intent(this,LoginCustomer.class));
        finish();
    }

    boolean isEmailValid(CharSequence email)
    {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    @SuppressLint("StaticFieldLeak")
    private class SignUpHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/signup_cust";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(SignUpCustomer.this);
            pDialog.setMessage("Logging In....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            if (isEmailValid(params[1].toString())) {
                RequestBody formBody = new FormBody.Builder()
                        .add("name", params[0].toString())
                        .add("email", params[1].toString())
                        .add("phone", params[2].toString())
                        .add("password", params[3].toString())
                        .build();

                Request.Builder builder = new Request.Builder();
                builder.url(url).post(formBody);
                Request request = builder.build();

                try {
                    Response response = client.newCall(request).execute();
                    //noinspection ConstantConditions
                    return response.body().string();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else {
                Toast.makeText(getApplicationContext(), "Email is invalid", Toast.LENGTH_LONG).show();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            } else {
                try {

                    //Toast.makeText(Login.this, o.toString(),Toast.LENGTH_SHORT).show();

                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":
                            JSONObject res = new JSONObject(response.getString("data"));

                            SharedPreferences pref = getApplicationContext().getSharedPreferences("STYLEIT", MODE_PRIVATE);
                            SharedPreferences.Editor editor = pref.edit();

                            editor.putString("sid", res.getString("custid"));
                            editor.putString("token", res.getString("token"));

                            editor.apply();
                            editor.commit();
                            startActivity(new Intent(SignUpCustomer.this,MainActivityCust.class));
                            finish();

                            break;
                        case "400":
                            Toast.makeText(getApplicationContext(), response.getString("UsersMessage"), Toast.LENGTH_LONG).show();
                            break;
                        case "422":
                            if (response.getString("DeveloperMessage").contains("Phone Number field is required")) {
                                Toast.makeText(getApplicationContext(), "Phone Number field is required", Toast.LENGTH_LONG).show();
                            } else if (response.getString("DeveloperMessage").contains("Email address field is required")) {
                                Toast.makeText(getApplicationContext(), "Email address field is required", Toast.LENGTH_LONG).show();
                            } else if (response.getString("DeveloperMessage").contains("Name field is required")) {
                                Toast.makeText(getApplicationContext(), "Name field is required", Toast.LENGTH_LONG).show();
                            } else if (response.getString("DeveloperMessage").contains("Password field is required")) {
                                Toast.makeText(getApplicationContext(), "Password field is required", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                            }
                            break;
                        default:
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        Util.onBackPressed(SignUpCustomer.this);
    }
}