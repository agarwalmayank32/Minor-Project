package info.mayankag.style_it.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import info.mayankag.style_it.Model.BookingDetailsCust;
import info.mayankag.style_it.R;

public class BookingDetailsAdapterCust extends ArrayAdapter<BookingDetailsCust> {

    private Activity mContext;
    private ArrayList<BookingDetailsCust> bookingDetailsCusts;

    public BookingDetailsAdapterCust(Activity context, ArrayList<BookingDetailsCust> bookingDetailsCusts) {
        super(context, R.layout.bookinghistoryadapter, bookingDetailsCusts);

        mContext = context;
        this.bookingDetailsCusts = bookingDetailsCusts;
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = mContext.getLayoutInflater();
        @SuppressLint({"ViewHolder", "InflateParams"})
        final View rowView = inflater.inflate(R.layout.bookinghistoryadapter, null, true);

        TextView bookingShopName = rowView.findViewById(R.id.bookingShopname);
        TextView bookingDate = rowView.findViewById(R.id.bookingDate);
        TextView bookingTime = rowView.findViewById(R.id.bookingTime);
        TextView bookingService = rowView.findViewById(R.id.bookingService);
        TextView bookingStatus = rowView.findViewById(R.id.bookingStatus);

        bookingShopName.setText(bookingDetailsCusts.get(position).getBookingShopName());
        bookingDate.setText(bookingDetailsCusts.get(position).getBookingDate());
        bookingTime.setText(bookingDetailsCusts.get(position).getBookingTime());
        bookingService.setText(bookingDetailsCusts.get(position).getBookingService());
        bookingStatus.setText(bookingDetailsCusts.get(position).getBookingStatus());

        return rowView;

    }
}