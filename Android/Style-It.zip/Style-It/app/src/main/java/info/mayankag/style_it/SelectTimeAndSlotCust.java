package info.mayankag.style_it;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SelectTimeAndSlotCust extends AppCompatActivity {

    Button date;
    Spinner time;
    String sid;
    String service;

    ArrayList<String> timeSlot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_time_and_slot_cust);

        date = findViewById(R.id.date);
        time = findViewById(R.id.time);

        timeSlot = new ArrayList<>();

        Bundle extra = getIntent().getExtras();
        if(extra!=null)
        {
            sid = extra.getString("sid");
            service = extra.getString("service");
        }

        time.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position>0)
                {
                    String time;
                    String t = timeSlot.get(position);

                    String temp[] = t.split(" ");

                    if(t.contains("PM") && t.contains("12"))
                    {
                        time = String.valueOf(Integer.parseInt(temp[0]));
                    }
                    else if(t.contains("PM"))
                    {
                        time = String.valueOf(Integer.parseInt(temp[0])+12);
                    }
                    else
                    {
                        time = String.valueOf(Integer.parseInt(temp[0]));
                    }

                    //noinspection unchecked
                    new bookingHandler().execute(
                            Util.getCustID(SelectTimeAndSlotCust.this),
                            sid, date.getText().toString(),
                            time, service);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void selectDate(View view)
    {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        final int month = cal.get(Calendar.MONTH);
        final int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog mDatePicker = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                String d = String.valueOf(year) + "-" + String.valueOf(monthOfYear + 1) + "-" + String.valueOf(dayOfMonth);
                date.setText(d);
                //noinspection unchecked
                new getTimeSlotHandler().execute(sid,d);
            }
        }, year, month, day);
        mDatePicker.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        mDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis() + 100000000);
        mDatePicker.setTitle("Select Date");
        mDatePicker.show();
    }

    @SuppressLint("StaticFieldLeak")
    private class getTimeSlotHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/get_time_slot";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(SelectTimeAndSlotCust.this);
            pDialog.setMessage("Fetching details....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            RequestBody formBody = new FormBody.Builder()
                    .add("sid",params[0].toString())
                    .add("date",params[1].toString())
                    .build();


            Request.Builder builder = new Request.Builder();
            builder.url(url).header("token" ,Util.getToken(SelectTimeAndSlotCust.this)).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            }
            else
            {
                try
                {
                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":

                            JSONArray detail = response.getJSONArray("data");

                            if(detail.length()>0)
                            {
                                timeSlot.clear();
                                timeSlot.add("Select Time");

                                for (int i = 0; i < detail.length(); i++) {
                                    JSONObject singleObject = detail.getJSONObject(i);
                                    int t = Integer.parseInt(singleObject.getString("time"));
                                    if(t>12)
                                    {
                                        timeSlot.add(String.valueOf(t-12)+" PM");
                                    }
                                    else if(t == 12)
                                    {
                                        timeSlot.add(String.valueOf(t)+" PM");
                                    }
                                    else
                                    {
                                        timeSlot.add(String.valueOf(t)+" AM");
                                    }
                                }
                            }
                            else
                            {
                                timeSlot.add("No Time Slot Available for this Date");
                            }

                            ArrayAdapter<String> timeAdapter = new ArrayAdapter<>(SelectTimeAndSlotCust.this, android.R.layout.simple_spinner_item, timeSlot);
                            timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            time.setAdapter(timeAdapter);

                            break;
                        case "400":
                            break;
                        case "401":
                        case "422":
                            Toast.makeText(SelectTimeAndSlotCust.this,"error",Toast.LENGTH_SHORT).show();
                            break;
                        case "402":
                            Toast.makeText(SelectTimeAndSlotCust.this,"Invalid User",Toast.LENGTH_SHORT).show();
                            Util.logout(SelectTimeAndSlotCust.this);
                            break;
                        default:

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class bookingHandler extends AsyncTask {

        String url = "http://139.59.63.21/manage_style/STYLE/book";

        final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        @SuppressWarnings("deprecation")
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();

            //noinspection deprecation
            pDialog = new ProgressDialog(SelectTimeAndSlotCust.this);
            pDialog.setMessage("Booking your service....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(Object[] params) {

            RequestBody formBody = new FormBody.Builder()
                    .add("custid",params[0].toString())
                    .add("sid",params[1].toString())
                    .add("date",params[2].toString())
                    .add("time",params[3].toString()+":00:00")
                    .add("service",params[4].toString())
                    .build();


            Request.Builder builder = new Request.Builder();
            builder.url(url).header("token" ,Util.getToken(SelectTimeAndSlotCust.this)).post(formBody);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                //noinspection ConstantConditions
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            //noinspection unchecked
            super.onPostExecute(o);
            if ((pDialog != null) && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (o == null) {
                Toast.makeText(getApplicationContext(), "Network Slow Try Again !", Toast.LENGTH_LONG).show();
            }
            else
            {
                try
                {
                    JSONObject response = new JSONObject(o.toString());
                    String status = response.getString("status");

                    switch (status) {
                        case "200":

                            startActivity(new Intent(SelectTimeAndSlotCust.this,BookingDoneCust.class));
                            finish();

                            break;
                        case "400":
                            break;
                        case "401":
                        case "422":
                            Toast.makeText(SelectTimeAndSlotCust.this,"error",Toast.LENGTH_SHORT).show();
                            break;
                        case "402":
                            Toast.makeText(SelectTimeAndSlotCust.this,"Invalid User",Toast.LENGTH_SHORT).show();
                            Util.logout(SelectTimeAndSlotCust.this);
                            break;
                        default:

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}