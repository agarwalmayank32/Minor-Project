package info.mayankag.style_it.Model;

public class ShopDetailsForCustomerSearch
{
    private String shopid;
    private String shopName;
    private String openTime;
    private String closeTime;

    private String service;

    public ShopDetailsForCustomerSearch(String shopid, String shopName, String openTime, String closeTime, String service)
    {
        this.shopid = shopid;
        this.shopName = shopName;
        this.openTime = openTime;
        this.closeTime = closeTime;
        this.service = service;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getShopid() {
        return shopid;
    }

    public void setShopid(String shopid) {
        this.shopid = shopid;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public String getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(String closeTime) {
        this.closeTime = closeTime;
    }
}
